import React, { Component } from "react";

export class Home extends Component {
  render() {
    return (
      <div>
        <img src="./img/wel.jpg" />
      </div>
    );
  }
}

export default Home;
